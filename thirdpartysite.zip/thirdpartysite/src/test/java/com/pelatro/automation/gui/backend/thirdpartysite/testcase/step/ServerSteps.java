package com.pelatro.automation.gui.backend.thirdpartysite.testcase.step;

import com.pelatro.automation.gui.backend.thirdpartysite.utils.ConnectRemoteServer;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ServerSteps {

	@Given("I created a directory (.*) in my home directory")
	public void createDirectory(String dirName) {
		new ConnectRemoteServer().execute("mkdir /home/pelatro/" + dirName);
		String ls = new ConnectRemoteServer().execute("ls /home/pelatro/");
		if (!ls.contains(dirName))
			throw new AssertionError("Directory creation failed !!!");
	}

	@And("I create (.*) files with (.*) lines each from (.*)")
	public void createAndInsertToFile(String noOfFiles, String noOfLines, String dirName) {
		ConnectRemoteServer connectRemoteServer = new ConnectRemoteServer();
		connectRemoteServer.execute("cd /home/pelatro/" + dirName);
		for (int i = 1; i <= Integer.parseInt(noOfFiles); i++) {
			String fileName = "/home/pelatro/" + dirName + "/file" + i + ".txt";
			String command = "";
			for (int j = 1; j <= Integer.parseInt(noOfLines); j++) {
				command += "echo \"This is line " + j + "in file " + i + "\" >> " + fileName + "; ";
			}
			connectRemoteServer.execute(command);

		}

	}

	@Then("I list all the files (.*)")
	public void listAllFiles(String dirName) {
		ConnectRemoteServer connectRemoteServer = new ConnectRemoteServer();

		String ls = "ls /home/pelatro/" + dirName;
		connectRemoteServer.execute(ls);
		if (ls.isEmpty())
			throw new AssertionError("No files are found");
	}

	@And("append content in these files to a (.*) file in (.*)")
	public void appendDataToTemp(String temp, String dirName) {
		ConnectRemoteServer connectRemoteServer = new ConnectRemoteServer();
		String append = "cat /home/pelatro/" + dirName + "/* >> /home/pelatro/" + dirName + "/" + temp;
		connectRemoteServer.execute(append);
		if (temp.isEmpty())
			throw new AssertionError("The file is empty");
	}

	@Then("I download the (.*) file from (.*) directory")
	public void downloadTemp(String temp,String dirName) {
		ConnectRemoteServer connectRemoteServer = new ConnectRemoteServer();
		String tempFile="/home/pelatro/"+dirName+"/" + temp;
		connectRemoteServer.download("/home/pelatro/Downloads", tempFile);
		if (!(connectRemoteServer.execute("ls /home/pelatro/Downloads").contains(temp)))
			throw new AssertionError("Downloaded file is not present");
	}
	@And("print the contents of the (.*) file")
	public void printTemp(String temp) {
		System.out.println(new ConnectRemoteServer().execute("cat /home/pelatro/Downloads/"+temp));

	}
}
