package com.pelatro.automation.gui.backend.thirdpartysite.testcase.step;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.openqa.selenium.WebElement;

import com.pelatro.automation.gui.backend.thirdpartysite.login.LoginPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginSteps {
	
	private LoginPage loginPage;
	
	@Given("I opened the app using following (.*)")
	public void openApp(String url) {
		loginPage.openAt(url);
	}
	@Given("enter (.*) and (.*) and click on submit button")
	public void enterUsernameAndPasswordAndSubmit(String username,String password) {
		
		loginPage.enterUserNamePasswordAndSubmit(username, password) ;
	}
	
	@Then("new page with following (.*)")
	public void  navigateToNewPage(String expectedUrl) {
	    String currentUrl=loginPage.getDriver().getCurrentUrl();
	    assertTrue("URL did not match",currentUrl.contains(expectedUrl));
		}
@And("text (.*) with logout button")
	public void printText(String text) {
		String page=loginPage.getDriver().getPageSource();
		assertTrue("expected text is not present",page.contains(text));
		boolean isLogoutVisible = loginPage.isLogoutButtonVisible();
	    assertTrue("Logout button is not visible on the page!", isLogoutVisible);

	}
@Then("wrong username message (.*) is displayed")
public void validateErrorMessage(String expectedError) {
    String actualError = loginPage.getErrorMessage();
    Assert.assertEquals("Error message did not match!", expectedError, actualError);
}

@Then("wrong password message (.*) is displayed")
public void passwordError(String error) {
	String actualError = loginPage.getErrorMessage();
    Assert.assertEquals("Error message for wrong username does not match.", error, actualError);
}
	

}