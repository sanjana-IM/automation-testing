package com.pelatro.automation.gui.backend.thirdpartysite.login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.pelatro.automation.gui.backend.thirdpartysite.generic.Page;


public class LoginPage extends Page {
	  

	public LoginPage(WebDriver driver) {
		super(driver);
	}
public void enterUserNamePasswordAndSubmit(String username, String password) {
		
		String userNameXpath = "//input[@id='username']";
		String passwordXpath="//input[@id='password']";
		String submitXpath= "//button[@id='submit']";
		type(userNameXpath,username);	
		type(passwordXpath,password);
		click(submitXpath);	
	}

public boolean isLogoutButtonVisible() {
	// TODO Auto-generated method stub
    //return driver.findElement(By.id("logout")).isDisplayed();
	try {
        WebElement logoutButton = driver.findElement(By.xpath("//div[@id='loop-container']"));
        return logoutButton.isDisplayed();
    } catch (Exception e) {
        return false; // If element is not found or not visible
    }
}

public void navigateTo(String nextUrl) {
	// TODO Auto-generated method stub
	if (!nextUrl.startsWith("http://") && !nextUrl.startsWith("https://")) {
		nextUrl = "https://" + nextUrl;  // Prepend the protocol if missing
    }
    driver.get(nextUrl); 
}
public String getErrorMessage() {
	WebElement errorElement = driver.findElement(By.xpath("//div[@id='error']"));
    return errorElement.getText().trim(); // Trim spaces around the text
}





}
