package com.pelatro.automation.gui.backend.thirdpartysite;

public class App {
  public static void main(String[] args) {
    System.out.println("Hello World!");
  }
}
